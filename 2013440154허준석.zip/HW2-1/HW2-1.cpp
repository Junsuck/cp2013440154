/////��Ŭ����/////
#include <stdio.h>
int main(){
	int a;
	while(1){
		a=1;
		while(a <= 10){
			printf("%d\n",a);
			a=a+1;
		}
	}
	return 0;
}