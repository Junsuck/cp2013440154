#include <stdio.h>
int main (){
int a , b, c ;
for(a=0;a<6;a++){
	if(a == 5)
		printf(" ");
printf("*");
}
printf("\n");

for(b=0;b<6;b++){
	if(b == 3)
		printf(" ");
printf("*");
}
printf("\n");

for(c=0;c<6;c++){
	if(c == 1)
		printf(" ");
printf("*");
}
printf("\n");


return 0 ;
}