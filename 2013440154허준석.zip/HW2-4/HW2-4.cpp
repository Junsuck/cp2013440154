#include <stdio.h>
int main (){
int a =0,sum=0;
for(a=3; a <=100; a=a+3){
	sum=sum+a;
}
printf("���� : %d\n",sum);
return 0 ;
}