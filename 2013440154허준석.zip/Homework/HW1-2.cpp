#include <stdio.h>;
int main(){
int a,b;
a=10;
b= a%2;

return 0;
#include <stdio.h>;
int main(){
int a,b;
a=10;
b= a%2;

return 0;
}